import { useState } from "react";
import axios from "axios";
import "./app.css";

function App() {
  const [url, setUrl] = useState("");
  const [model, setModel] = useState("rf");
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  const analyze = async () => {
    if (!url) return;

    setLoading(true);
    setData(null);

    try {
      const res = await axios.post("http://127.0.0.1:5000/predict", {
        url,
        model,
      });

      setData(res.data);
    } catch (err) {
      alert("Backend error");
    }

    setLoading(false);
  };

  const riskClass = (level) => {
    if (level === "High Risk") return "risk-high";
    if (level === "Medium Risk") return "risk-medium";
    return "risk-low";
  };

  // 🔥 FIX OVERCONFIDENCE DISPLAY
  const calibratedConfidence = (val) => {
    if (!val) return 0;
    return Math.min(0.95, val); // cap at 95%
  };

  return (
    <div className="container">
      <h1 className="title">⚡ Cyber Phishing Detector</h1>

      <div className="input-box">
        <input
          type="text"
          placeholder="Enter URL..."
          value={url}
          onChange={(e) => setUrl(e.target.value)}
        />

        <select value={model} onChange={(e) => setModel(e.target.value)}>
          <option value="rf">Random Forest</option>
          <option value="lr">Logistic Regression</option>
        </select>

        <button onClick={analyze}>Scan</button>
      </div>

      {loading && <p className="loading">🔍 Scanning...</p>}

      {data && (
        <div className="card">

          {/* RESULT */}
          <h2>Result: {data.prediction}</h2>

          <h3 className={riskClass(data.risk_level)}>
            {data.risk_level}
          </h3>

          <p className="message">{data.message}</p>

          <hr />

          {/* MODEL INFO */}
          <h3>🤖 Model Info</h3>
          <p><strong>Model Used:</strong> {data.model_used}</p>
          <p><strong>ML Prediction:</strong> {data.ml_prediction}</p>
          <p>
            <strong>ML Confidence:</strong>{" "}
            {calibratedConfidence(data.ml_phishing_probability)}
          </p>

          {/* 🔥 DISAGREEMENT UI */}
          {data.ml_prediction !== data.prediction && (
            <div className="disagreement-box">
              ⚠️ Model Disagreement Detected
              <p>
                ML Model predicted <strong>{data.ml_prediction}</strong> but
                final decision is <strong>{data.prediction}</strong>.
              </p>
              <p className="hint">
                Final result is refined using real-time security analysis.
              </p>
            </div>
          )}

          <hr />

          {/* RISK */}
          <h3>📊 Risk Analysis</h3>
          <p><strong>Confidence:</strong> {data.confidence}</p>
          <p><strong>Risk Score:</strong> {data.risk_score}</p>

          <hr />

          {/* URL */}
          <h3>🌐 URL Details</h3>
          <p><strong>Input:</strong> {data.url}</p>
          <p><strong>Final:</strong> {data.security_analysis.final_url}</p>
          <p><strong>Domain:</strong> {data.security_analysis.final_domain}</p>

          <hr />

          {/* REDIRECT */}
          <h3>🔁 Redirect Info</h3>
          <p>Redirects: {data.security_analysis.redirects}</p>
          <p>
            Domain Changed:{" "}
            {data.security_analysis.domain_changed_after_redirect ? "Yes" : "No"}
          </p>

          <hr />

          {/* DOMAIN */}
          <h3>📅 Domain Info</h3>
          <p>Age: {data.security_analysis.domain_age_days}</p>

          <hr />

          {/* HTML */}
          <h3>🧠 HTML Signals</h3>
          <p>Forms: {data.security_analysis.html_signals.form_count}</p>
          <p>Password: {data.security_analysis.html_signals.has_password}</p>
          <p>External Forms: {data.security_analysis.html_signals.external_forms}</p>
          <p>Iframes: {data.security_analysis.html_signals.iframe_count}</p>
          <p>Scripts: {data.security_analysis.html_signals.suspicious_scripts}</p>

          <hr />

          {/* REASONS */}
          <h3>⚠️ Reasons</h3>
          <ul>
            {data.reasons.length > 0
              ? data.reasons.map((r, i) => <li key={i}>{r}</li>)
              : <li>No major risks detected</li>}
          </ul>

        </div>
      )}
    </div>
  );
}

export default App;