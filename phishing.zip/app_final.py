from flask import Flask, request, jsonify
from flask_cors import CORS
import pandas as pd
import joblib
import requests
import tldextract
import re

from urllib.parse import urlparse, urljoin
from bs4 import BeautifulSoup
from datetime import datetime, timezone
from dateutil import parser as date_parser

app = Flask(__name__)
CORS(app, resources={r"/*": {"origins": "*"}})

# -----------------------------
# LOAD MODELS
# -----------------------------
lr_model = joblib.load("lr_model.pkl")
rf_model = joblib.load("rf_model.pkl")
feature_names = joblib.load("features.pkl")

REQUEST_TIMEOUT = 8

SHORTENERS = ["bit.ly", "tinyurl.com", "goo.gl", "t.co", "ow.ly", "is.gd"]
SUSPICIOUS_WORDS = [
    "login", "verify", "secure", "account", "bank", "signin",
    "confirm", "update", "password", "paypal", "wallet", "webscr"
]

HEADERS = {
    "User-Agent": "Mozilla/5.0"
}


# -----------------------------
# HELPERS
# -----------------------------
def normalize_url(url: str) -> str:
    url = (url or "").strip()
    if not url:
        return ""
    if not re.match(r"^https?://", url, re.IGNORECASE):
        url = "http://" + url
    return url


def get_registered_domain(url: str) -> str:
    ext = tldextract.extract(url)
    return ".".join(part for part in [ext.domain, ext.suffix] if part)


def get_model(model_key: str):
    key = (model_key or "rf").lower()
    if key == "lr":
        return lr_model, "Logistic Regression"
    return rf_model, "Random Forest"


# -----------------------------
# FEATURE EXTRACTION FOR MODEL
# -----------------------------
def extract_model_features(url: str):
    """
    Approximate live feature extraction mapped to UCI-style columns.
    This is not perfect, but good enough for live demo/model inference.
    """
    parsed = urlparse(url)
    ext = tldextract.extract(url)

    host = parsed.netloc.lower().split(":")[0]
    path = parsed.path.lower()
    full = url.lower()

    subdomain_parts = [p for p in ext.subdomain.split(".") if p] if ext.subdomain else []

    features = {
        "having_IPhaving_IP_Address": -1 if re.search(r"(?:\d{1,3}\.){3}\d{1,3}", host) else 1,
        "URLURL_Length": 1 if len(url) < 54 else 0 if len(url) <= 75 else -1,
        "Shortining_Service": -1 if any(host == s or host.endswith("." + s) for s in SHORTENERS) else 1,
        "having_At_Symbol": -1 if "@" in url else 1,
        "double_slash_redirecting": -1 if full.rfind("//") > 6 else 1,
        "Prefix_Suffix": -1 if "-" in ext.domain else 1,
        "having_Sub_Domain": -1 if len(subdomain_parts) > 1 else 0 if len(subdomain_parts) == 1 else 1,
        "SSLfinal_State": 1 if parsed.scheme == "https" else -1,
        "Domain_registeration_length": 1,   # replaced by live analysis layer later
        "Favicon": 1,
        "port": -1 if ":" in parsed.netloc and parsed.port not in [80, 443, None] else 1,
        "HTTPS_token": -1 if "https" in ext.domain else 1,
        "Request_URL": 1,
        "URL_of_Anchor": 1,
        "Links_in_tags": 1,
        "SFH": 1,
        "Submitting_to_email": -1 if "mailto:" in full else 1,
        "Abnormal_URL": -1 if ext.domain and ext.domain not in host else 1,
        "Redirect": 0,
        "on_mouseover": 1,
        "RightClick": 1,
        "popUpWidnow": 1,
        "Iframe": 1,
        "age_of_domain": 1,
        "DNSRecord": 1,
        "web_traffic": 0,
        "Page_Rank": 1,
        "Google_Index": 1,
        "Links_pointing_to_page": 0,
        "Statistical_report": -1 if any(w in full for w in ["paypal", "signin", "login", "verify"]) else 1,
    }

    return {col: features.get(col, 1) for col in feature_names}


# -----------------------------
# DOMAIN AGE
# -----------------------------
def get_domain_age_days(domain: str):
    if not domain:
        return None

    try:
        r = requests.get(f"https://rdap.org/domain/{domain}", headers=HEADERS, timeout=REQUEST_TIMEOUT)
        if r.status_code != 200:
            return None

        data = r.json()
        events = data.get("events", [])

        for event in events:
            action = (event.get("eventAction") or "").lower()
            if action in {"registration", "registered"}:
                dt = date_parser.parse(event["eventDate"])
                if dt.tzinfo is None:
                    dt = dt.replace(tzinfo=timezone.utc)
                return max((datetime.now(timezone.utc) - dt).days, 0)
    except Exception:
        return None

    return None


# -----------------------------
# FETCH + REDIRECTS
# -----------------------------
def fetch_url(url: str):
    try:
        response = requests.get(
            url,
            headers=HEADERS,
            timeout=REQUEST_TIMEOUT,
            allow_redirects=True
        )
        return response
    except Exception:
        return None


def analyze_redirects(original_url: str, response):
    if response is None:
        return {
            "redirects": 0,
            "final_url": original_url,
            "input_domain": get_registered_domain(original_url),
            "final_domain": get_registered_domain(original_url),
            "domain_changed_after_redirect": False
        }

    input_domain = get_registered_domain(original_url)
    final_url = response.url
    final_domain = get_registered_domain(final_url)

    return {
        "redirects": len(response.history),
        "final_url": final_url,
        "input_domain": input_domain,
        "final_domain": final_domain,
        "domain_changed_after_redirect": input_domain != final_domain
    }


# -----------------------------
# HTML ANALYSIS
# -----------------------------
def analyze_html(url: str, html: str):
    signals = {
        "form_count": 0,
        "has_password": 0,
        "iframe_count": 0,
        "external_forms": 0,
        "suspicious_scripts": 0
    }

    if not html:
        return signals

    try:
        soup = BeautifulSoup(html, "html.parser")
        page_domain = get_registered_domain(url)

        forms = soup.find_all("form")
        inputs = soup.find_all("input")
        iframes = soup.find_all("iframe")
        scripts = soup.find_all("script")

        signals["form_count"] = len(forms)
        signals["iframe_count"] = len(iframes)

        for i in inputs:
            if (i.get("type") or "").lower() == "password":
                signals["has_password"] = 1
                break

        external_forms = 0
        for form in forms:
            action = (form.get("action") or "").strip()
            if not action:
                continue

            action_url = urljoin(url, action)
            action_domain = get_registered_domain(action_url)

            # only count as external if domain really differs
            if action_domain and action_domain != page_domain:
                external_forms += 1

        signals["external_forms"] = external_forms

        high_risk_patterns = [
            "eval(atob(",
            "document.write(unescape(",
            "window.location='http",
            'window.location="http',
            "location.href='http",
            'location.href="http'
        ]

        suspicious_scripts = 0
        for script in scripts:
            content = script.get_text(" ", strip=True).lower()
            if any(p in content for p in high_risk_patterns):
                suspicious_scripts += 1

        signals["suspicious_scripts"] = suspicious_scripts

    except Exception:
        pass

    return signals


# -----------------------------
# DECISION ENGINE
# -----------------------------
def build_security_assessment(domain_age_days, redirect_info, html_signals, final_url):
    """
    Weighted security layer used to validate ML result.
    Helps reduce false positives from live feature approximation.
    """
    risk_score = 0
    reasons = []

    final_url_lower = final_url.lower()

    def add(score, reason):
        nonlocal risk_score
        risk_score += score
        reasons.append(reason)

    # Domain age
    if domain_age_days is not None:
        if domain_age_days < 30:
            add(40, f"Very new domain detected ({domain_age_days} days old)")
        elif domain_age_days < 180:
            add(15, f"Recently registered domain ({domain_age_days} days old)")
        elif domain_age_days > 365:
            add(-20, f"Established domain ({domain_age_days} days old)")
    else:
        add(0, "Domain age unavailable")

    # Redirects
    if redirect_info["redirects"] > 2:
        add(25, f"Multiple redirects detected ({redirect_info['redirects']})")
    elif redirect_info["redirects"] == 0:
        add(-5, "No redirects detected")

    if redirect_info["domain_changed_after_redirect"]:
        add(30, "Domain changed after redirect")

    # HTML
    if html_signals["has_password"] == 1:
        add(30, "Login form detected")

    if html_signals["external_forms"] > 3:
        add(20, f"Multiple external form submissions detected ({html_signals['external_forms']})")
    elif html_signals["external_forms"] > 0:
        add(5, f"External form submission detected ({html_signals['external_forms']})")

    if html_signals["suspicious_scripts"] > 0:
        add(25, "Suspicious JavaScript detected")

    if html_signals["iframe_count"] > 2:
        add(10, f"Multiple iframes detected ({html_signals['iframe_count']})")

    # URL lexical live check
    if any(word in final_url_lower for word in SUSPICIOUS_WORDS):
        add(15, "Suspicious keywords detected in URL")

    if final_url_lower.startswith("http://"):
        add(15, "No HTTPS detected")
    else:
        add(-5, "HTTPS is present")

    host = urlparse(final_url).netloc.lower()
    if host.count("-") > 2:
        add(10, "Excessive hyphens detected")

    risk_score = max(0, min(100, 50 + risk_score))
    return risk_score, reasons


def combine_ml_and_security(pred, proba, security_score, html_signals, domain_age_days):
    """
    Final decision logic:
    - ML prediction is advisory
    - security score validates/overrides
    """
    ml_prediction = "Phishing" if pred == 1 else "Legitimate"
    phishing_probability = float(proba[1]) if len(proba) > 1 else float(max(proba))

    # Weighted final decision
    if ml_prediction == "Phishing":
        if security_score < 35 and html_signals["has_password"] == 0 and (domain_age_days is None or domain_age_days > 365):
            final_prediction = "Legitimate"
        elif security_score < 60:
            final_prediction = "Suspicious"
        else:
            final_prediction = "Phishing"
    else:
        if security_score >= 75:
            final_prediction = "Phishing"
        elif security_score >= 45:
            final_prediction = "Suspicious"
        else:
            final_prediction = "Legitimate"

    # Confidence tied to security score, capped realistically
    confidence = round(min(0.95, max(security_score, 100 - security_score) / 100), 4)

    if security_score < 30:
        risk_level = "Low Risk"
        message = "This site appears relatively safe based on current analysis."
    elif security_score < 70:
        risk_level = "Medium Risk"
        message = "This site shows some suspicious indicators. Proceed carefully."
    else:
        risk_level = "High Risk"
        message = "This site shows strong phishing indicators. Avoid entering sensitive information."

    return {
        "ml_prediction": ml_prediction,
        "ml_phishing_probability": round(phishing_probability, 4),
        "prediction": final_prediction,
        "confidence": confidence,
        "risk_score": round(float(security_score), 2),
        "risk_level": risk_level,
        "message": message,
    }


# -----------------------------
# API
# -----------------------------
@app.route("/predict", methods=["POST", "OPTIONS"])
def predict():
    if request.method == "OPTIONS":
        return jsonify({"status": "ok"}), 200

    data = request.get_json(silent=True) or {}
    url = normalize_url(data.get("url", ""))
    model_key = data.get("model", "rf")

    if not url:
        return jsonify({"error": "URL not provided"}), 400

    model, model_name = get_model(model_key)

    # ML prediction
    feature_dict = extract_model_features(url)
    features_df = pd.DataFrame([feature_dict], columns=feature_names)

    pred = int(model.predict(features_df)[0])
    probs = model.predict_proba(features_df)[0]

    # Live security analysis
    response = fetch_url(url)
    redirect_info = analyze_redirects(url, response)
    final_url = redirect_info["final_url"]
    final_domain = redirect_info["final_domain"]

    domain_age_days = get_domain_age_days(final_domain)
    html_signals = analyze_html(final_url, response.text if response is not None else "")

    security_score, reasons = build_security_assessment(
        domain_age_days=domain_age_days,
        redirect_info=redirect_info,
        html_signals=html_signals,
        final_url=final_url
    )

    final_result = combine_ml_and_security(
        pred=pred,
        proba=probs,
        security_score=security_score,
        html_signals=html_signals,
        domain_age_days=domain_age_days
    )

    return jsonify({
        "url": url,
        "model_used": model_name,
        "prediction": final_result["prediction"],
        "confidence": final_result["confidence"],
        "risk_score": final_result["risk_score"],
        "risk_level": final_result["risk_level"],
        "message": final_result["message"],
        "ml_prediction": final_result["ml_prediction"],
        "ml_phishing_probability": final_result["ml_phishing_probability"],
        "security_analysis": {
            "domain_age_days": domain_age_days if domain_age_days is not None else "Unavailable",
            "redirects": redirect_info["redirects"],
            "final_url": final_url,
            "input_domain": redirect_info["input_domain"],
            "final_domain": redirect_info["final_domain"],
            "domain_changed_after_redirect": redirect_info["domain_changed_after_redirect"],
            "html_signals": html_signals
        },
        "reasons": reasons[:6],
        "features_used": feature_dict
    })


if __name__ == "__main__":
    app.run(debug=True)