import matplotlib.pyplot as plt
import numpy as np

print("="*50)
print(" MODEL COMPARISON ")
print("="*50)

# ---------------------------
# YOUR ACTUAL RESULTS
# ---------------------------

lr_metrics = {
    "Accuracy": 0.9245,
    "Precision": 0.9283,
    "Recall": 0.9394,
    "F1 Score": 0.9339
}

rf_metrics = {
    "Accuracy": 0.9679,
    "Precision": 0.9647,
    "Recall": 0.9793,
    "F1 Score": 0.9719
}

# ---------------------------
# PRINT SUMMARY
# ---------------------------
print("\nLogistic Regression Results:")
for k, v in lr_metrics.items():
    print(f"{k}: {v:.4f}")

print("\nRandom Forest Results:")
for k, v in rf_metrics.items():
    print(f"{k}: {v:.4f}")

# ---------------------------
# BAR CHART COMPARISON
# ---------------------------
labels = list(lr_metrics.keys())

lr_values = list(lr_metrics.values())
rf_values = list(rf_metrics.values())

x = np.arange(len(labels))
width = 0.35

plt.figure()

plt.bar(x - width/2, lr_values, width, label="Logistic Regression")
plt.bar(x + width/2, rf_values, width, label="Random Forest")

plt.xticks(x, labels)
plt.ylim(0.85, 1.0)

plt.ylabel("Score")
plt.title("Model Performance Comparison")
plt.legend()

# Add values on top
for i in range(len(labels)):
    plt.text(x[i] - width/2, lr_values[i] + 0.002, f"{lr_values[i]:.2f}", ha='center')
    plt.text(x[i] + width/2, rf_values[i] + 0.002, f"{rf_values[i]:.2f}", ha='center')

plt.savefig("model_comparison.png")
plt.close()

# ---------------------------
# DIFFERENCE GRAPH (IMPORTANT 🔥)
# ---------------------------
diff = [rf_values[i] - lr_values[i] for i in range(len(labels))]

plt.figure()
plt.bar(labels, diff)

plt.title("Performance Improvement (RF over LR)")
plt.ylabel("Improvement")

plt.savefig("model_difference.png")
plt.close()

print("\nGraphs saved:")
print("model_comparison.png")
print("model_difference.png")

print("\n" + "="*50)
print(" COMPARISON COMPLETED ")
print("="*50)