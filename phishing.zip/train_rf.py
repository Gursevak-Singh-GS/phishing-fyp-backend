import pandas as pd
import matplotlib.pyplot as plt
import joblib

from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    ConfusionMatrixDisplay,
    precision_score,
    recall_score,
    f1_score,
    roc_curve,
    auc
)

print("="*50)
print(" RANDOM FOREST TRAINING ")
print("="*50)

# ---------------------------
# LOAD DATASET
# ---------------------------
print("\nLoading dataset...")
df = pd.read_csv("dataset.csv")

# Drop index if exists
if "index" in df.columns:
    df = df.drop("index", axis=1)

print("Dataset Shape:", df.shape)

# ---------------------------
# PREPROCESSING
# ---------------------------
X = df.drop("Result", axis=1)

# Convert labels: -1 → 0
y = df["Result"].replace(-1, 0)

print("Features:", X.shape)
print("Target:", y.shape)

# ---------------------------
# TRAIN TEST SPLIT
# ---------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)

print("Training Samples:", X_train.shape)
print("Testing Samples:", X_test.shape)

# ---------------------------
# TRAIN MODEL
# ---------------------------
print("\nTraining Random Forest...")

model = RandomForestClassifier(
    n_estimators=200,
    max_depth=None,
    random_state=42,
    n_jobs=-1
)

model.fit(X_train, y_train)

# ---------------------------
# PREDICTIONS
# ---------------------------
y_pred = model.predict(X_test)
y_prob = model.predict_proba(X_test)[:, 1]

# ---------------------------
# METRICS
# ---------------------------
accuracy = accuracy_score(y_test, y_pred)
precision = precision_score(y_test, y_pred)
recall = recall_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred)

print("\nRESULTS")
print("-"*30)
print(f"Accuracy  : {accuracy:.4f}")
print(f"Precision : {precision:.4f}")
print(f"Recall    : {recall:.4f}")
print(f"F1 Score  : {f1:.4f}")

# ---------------------------
# SAVE MODEL
# ---------------------------
joblib.dump(model, "rf_model.pkl")
joblib.dump(X.columns.tolist(), "features.pkl")

print("\nModel saved as rf_model.pkl")

# ---------------------------
# GRAPH 1 — CONFUSION MATRIX
# ---------------------------
cm = confusion_matrix(y_test, y_pred)

disp = ConfusionMatrixDisplay(confusion_matrix=cm)
disp.plot()

plt.title("Random Forest - Confusion Matrix")
plt.savefig("rf_confusion_matrix.png")
plt.close()

# ---------------------------
# GRAPH 2 — METRICS BAR CHART
# ---------------------------
metrics = ["Accuracy", "Precision", "Recall", "F1"]
values = [accuracy, precision, recall, f1]

plt.figure()
plt.bar(metrics, values)
plt.title("Random Forest Performance")
plt.ylabel("Score")
plt.ylim(0, 1)

plt.savefig("rf_metrics.png")
plt.close()

# ---------------------------
# GRAPH 3 — ROC CURVE
# ---------------------------
fpr, tpr, _ = roc_curve(y_test, y_prob)
roc_auc = auc(fpr, tpr)

plt.figure()
plt.plot(fpr, tpr, label=f"AUC = {roc_auc:.2f}")
plt.plot([0, 1], [0, 1], linestyle="--")

plt.xlabel("False Positive Rate")
plt.ylabel("True Positive Rate")
plt.title("ROC Curve - Random Forest")
plt.legend()

plt.savefig("rf_roc_curve.png")
plt.close()

# ---------------------------
# GRAPH 4 — FEATURE IMPORTANCE (VERY IMPORTANT 🔥)
# ---------------------------
importances = model.feature_importances_
features = X.columns

# Sort
indices = importances.argsort()[-10:]  # top 10

plt.figure()
plt.barh(range(len(indices)), importances[indices])
plt.yticks(range(len(indices)), [features[i] for i in indices])
plt.title("Top 10 Feature Importances (Random Forest)")

plt.savefig("rf_feature_importance.png")
plt.close()

print("\nGraphs saved:")
print("rf_confusion_matrix.png")
print("rf_metrics.png")
print("rf_roc_curve.png")
print("rf_feature_importance.png")

print("\n" + "="*50)
print(" TRAINING COMPLETED ")
print("="*50)