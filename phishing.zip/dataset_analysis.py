import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

print("\n==============================")
print("PHISHING DATASET ANALYSIS")
print("==============================\n")

# -----------------------------
# Load UCI Dataset
# -----------------------------

print("Loading UCI Phishing Dataset...\n")

uci_data = pd.read_csv("UCI Phishing/dataset.csv")

print("First 5 rows:")
print(uci_data.head())

print("\nDataset Shape:")
print(uci_data.shape)

print("\nColumn Names:")
print(uci_data.columns)

print("\nDataset Info:")
print(uci_data.info())

print("\nStatistical Summary:")
print(uci_data.describe())

print("\nMissing Values:")
print(uci_data.isnull().sum())

# -----------------------------
# Class Distribution
# -----------------------------

if 'Result' in uci_data.columns:

    plt.figure(figsize=(6,4))
    sns.countplot(x=uci_data['Result'])
    plt.title("Phishing vs Legitimate Distribution")
    plt.show()

# -----------------------------
# Correlation Heatmap
# -----------------------------

plt.figure(figsize=(12,8))
sns.heatmap(uci_data.corr(), cmap="coolwarm")
plt.title("Feature Correlation Heatmap")
plt.show()

# -----------------------------
# Feature Distribution Example
# -----------------------------

feature = uci_data.columns[0]

plt.figure(figsize=(6,4))
sns.histplot(uci_data[feature], bins=20)
plt.title(f"Distribution of {feature}")
plt.show()

# -----------------------------
# Load URL Dataset
# -----------------------------

print("\nLoading URL Dataset...\n")

url_data = pd.read_csv("Phishing URL Dataset/phishing_site_urls.csv")

print("First 5 rows:")
print(url_data.head())

print("\nDataset Shape:")
print(url_data.shape)

print("\nColumn Names:")
print(url_data.columns)

print("\nMissing Values:")
print(url_data.isnull().sum())

# -----------------------------
# URL Dataset Class Distribution
# -----------------------------

if 'label' in url_data.columns:

    plt.figure(figsize=(6,4))
    sns.countplot(x=url_data['label'])
    plt.title("URL Dataset Class Distribution")
    plt.show()

print("\nAnalysis Completed Successfully.")